#include "prt_task_external.h"
#include "os_attr_armv8_external.h"
#include "prt_asm_cpu_external.h"
#include "os_cpu_armv8_external.h"
#include "prt_tick.h"

#define LIST_FIRST_ELEM(listObject, type, member) \
    LIST_COMPONENT((listObject)->next, type, member)
// prt_config.h
#define OS_TASK_TIME_SLICE_TICKS 0.1  // 假设时间片为 10 个 Tick
// os_task.c
volatile U64 taskStartTick = 0;  // 记录任务开始运行的 Tick 值

//222222222222222

//1111111111111111111111111111111111
// 从链表头节点获取第一个元素的外层结构体（如任务控制块）


/**
 * @brief 将任务从队列中移除
 * @param queue 队列指针（哨兵节点）
 * @param task 任务控制块指针
 */
OS_SEC_ALW_INLINE INLINE void OsDequeueTaskAmp(struct TagListObject *queue, struct TagTskCb *task)
{
    uintptr_t intSave = OsIntLock();  // 关中断保护临界区

    // 若队列不为空且任务有效，则删除节点
    if (!ListEmpty(queue) && &task->pendList != queue) {
        ListDelete(&task->pendList);  // 调用现有 ListDelete 函数删除节点
    }

    OsIntRestore(intSave);  // 恢复中断
}
/**
 * @brief 将任务插入队列末尾
 * @param queue 队列指针（哨兵节点）
 * @param task 任务控制块指针
 */
OS_SEC_ALW_INLINE INLINE void OsEnqueueTaskAmp(struct TagListObject *queue, struct TagTskCb *task)
{
    uintptr_t intSave = OsIntLock();  // 关中断保护临界区

    // 将任务节点添加到队尾
    ListTailAdd(&task->pendList, queue);  // 调用现有 ListTailAdd 函数

    OsIntRestore(intSave);  // 恢复中断
}

/*
 * 描述: 从队列中取出第一个元素，然后插入到队列的最后
 */
OS_SEC_ALW_INLINE INLINE void ListPopAndPushFirst(struct TagListObject *listObject)
{
    struct TagTskCb *taskCb = NULL;
    taskCb = LIST_FIRST_ELEM(listObject, struct TagTskCb, pendList);
    OsDequeueTaskAmp(&g_runQueue, taskCb);
    OsEnqueueTaskAmp(&g_runQueue, taskCb);
}



/*
 * 描述: 根据FIFO调度算法设置当前任务
 */
OS_SEC_ALW_INLINE INLINE void OsTskFIFOSet(void)
{
    struct TagTskCb *nextTaskCb = NULL;
    nextTaskCb = LIST_FIRST_ELEM(&g_runQueue, struct TagTskCb, pendList);
    if (nextTaskCb->taskPid == g_idleTaskId)
    {
        ListPopAndPushFirst(&g_runQueue);
        nextTaskCb = LIST_FIRST_ELEM(&g_runQueue, struct TagTskCb, pendList);
    }
    g_highestTask = nextTaskCb;
}


/*
* 描述：任务调度，切换到最高优先级任务
*/
OS_SEC_TEXT void OsTskSchedule(void)
{
    /* 外层已经关中断 */
    /* Find the highest task */
    OsTskFIFOSet();
    /* In case that running is not highest then reschedule */
    if ((g_highestTask != RUNNING_TASK) && (g_uniTaskLock == 0)) {
        UNI_FLAG |= OS_FLG_TSK_REQ;

        /* only if there is not HWI or TICK the trap */
        if (OS_INT_INACTIVE) { // 不在中断上下文中，否则应该在中断返回时切换
            OsTaskTrap();
            return;
        }
    }

    return;
}

/*
 * 描述: 调度的主入口
 * 备注: NA
 */
OS_SEC_L0_TEXT void OsMainSchedule(void)
{
    struct TagTskCb *prevTsk;
    if ((UNI_FLAG & OS_FLG_TSK_REQ) != 0)
    {
        prevTsk = RUNNING_TASK;

        /* 清除OS_FLG_TSK_REQ标记位 */
        UNI_FLAG &= ~OS_FLG_TSK_REQ;

        RUNNING_TASK->taskStatus &= ~OS_TSK_RUNNING;
        g_highestTask->taskStatus |= OS_TSK_RUNNING;

        RUNNING_TASK = g_highestTask;

        taskStartTick = PRT_TickGetCount();
    }
    // 如果中断没有驱动一个任务ready，直接回到被打断的任务
    OsTskContextLoad((uintptr_t)RUNNING_TASK);
}



/*
* 描述: 系统启动时的首次任务调度
* 备注: NA
*/
/*
 * 描述: 系统启动时的首次任务调度
 * 备注: NA
 */
OS_SEC_L4_TEXT void OsFirstTimeSwitch(void)
{
    OsTskFIFOSet();
    RUNNING_TASK = g_highestTask;
    taskStartTick = PRT_TickGetCount();
    TSK_STATUS_SET(RUNNING_TASK, OS_TSK_RUNNING);
    OsTskContextLoad((uintptr_t)RUNNING_TASK);
    // never get here
    return;
}







//3333333333333333


/*
 * 描述: 定时器中断处理函数
 */
OS_SEC_TEXT void OsTimerInterrupt(void)
{
    OsGicIntClear(30); // 必须清除中断，否则系统会一直处于中断状态，就无法再次进入中断
    if ((OS_FLG_BGD_ACTIVE & UNI_FLAG) == 0)
    {
        return;
    }
   
    if (PRT_TickGetCount() - taskStartTick > OS_TASK_TIME_SLICE_TICKS)
    {
        if ((RUNNING_TASK->taskStatus & OS_TSK_READY) != 0)
        { // Fix the comparison operator
            ListPopAndPushFirst(&g_runQueue);
        }
        OsTskSchedule();
    }
}

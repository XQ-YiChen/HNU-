#include "prt_typedef.h"
#include "prt_tick.h"
#include "prt_task.h"
#include "prt_sem.h"

extern U32 PRT_Printf(const char *format, ...);
extern void PRT_UartInit(void);
extern U32 OsActivate(void);
extern U32 OsTskInit(void);
extern U32 OsSemInit(void);


static SemHandle sem_sync;

void Delay(U64 delay_ms)
{
    U64 end_time = PRT_TickGetCount() + delay_ms;
    while (PRT_TickGetCount() < end_time)
        ;
}
// //死锁实现
static SemHandle sem1;
static SemHandle sem2;
// void Test1TaskEntry()
// {
//     PRT_Printf("Task 1: Trying to acquire sem1\n");
//     PRT_SemPend(sem1, OS_WAIT_FOREVER);
//     PRT_Printf("Task 1: Acquired sem1\n");
   
//     Delay(200);
  


//     PRT_Printf("Task 1: Trying to acquire sem2\n");
//     PRT_SemPend(sem2, OS_WAIT_FOREVER);  // 这里会导致死锁
//     PRT_Printf("Task 1: Acquired sem2\n");

//     // 执行一些操作
//     PRT_SemPost(sem2);
//     PRT_SemPost(sem1);

//     PRT_Printf("Task 1: Released sem1 and sem2\n");

// }

// void Test2TaskEntry()
// {
//     PRT_Printf("Task 2: Trying to acquire sem2\n");
//     PRT_SemPend(sem2, OS_WAIT_FOREVER);
//     PRT_Printf("Task 2: Acquired sem2\n");
//     Delay(200);
  
//     PRT_Printf("Task 2: Trying to acquire sem1\n");
//     PRT_SemPend(sem1, OS_WAIT_FOREVER);  // 这里会导致死锁
//     PRT_Printf("Task 2: Acquired sem1\n");

//     // 执行一些操作
//     PRT_SemPost(sem1);
//     PRT_SemPost(sem2);

//     PRT_Printf("Task 2: Released sem1 and sem2\n");
// }


//活锁实现
static SemHandle sem1;
static SemHandle sem2;
void Test1TaskEntry()
{
    while (1) {
        if (PRT_SemPend(sem1, 0) == OS_OK) {
            PRT_Printf("Task 1 acquired sem1, trying to acquire sem2...\n");
            Delay(200);
            if (PRT_SemPend(sem2, 0) == OS_OK) {
                PRT_Printf("Task 1 acquired sem2, doing work...\n");
                PRT_SemPost(sem2);
                PRT_SemPost(sem1);
                break;
            } else {
                PRT_Printf("Task 1 failed to acquire sem2, releasing sem1 and retrying...\n");
                PRT_SemPost(sem1);
                
            }
        } else {
            PRT_Printf("Task 1 failed to acquire sem1, retrying...\n");
            Delay(200); 
        }
    }
}

void Test2TaskEntry()
{
     while (1) {
        if (PRT_SemPend(sem2, 0) == OS_OK) {
            PRT_Printf("Task 2 acquired sem2, trying to acquire sem1...\n");
            Delay(200);
            if (PRT_SemPend(sem1, 0) == OS_OK) {
                PRT_Printf("Task 2 acquired sem1, doing work...\n");
                PRT_SemPost(sem1);
                PRT_SemPost(sem2);
                break;
            } else {
                PRT_Printf("Task 2 failed to acquire sem1, releasing sem2 and retrying...\n");
                PRT_SemPost(sem2);
               
            }
        } else {
            PRT_Printf("Task 2 failed to acquire sem2, retrying...\n");
            Delay(200); 
        }
    }
}

// //违反原子性缺陷
// static SemHandle sem_lock;
// static int data = 10;
// static int *ptr = &data;
// void Test1TaskEntry()
// {
//     PRT_Printf("task 1 run ...\n");
//     if(ptr)
//     {
//         OsTskSchedule();
//         PRT_Printf("ptr is not empty,*ptr = %d\n",*ptr);
//     }
//     else
//     {
//         PRT_Printf("prt is empty");
//     }
//     U32 cnt =5;
//     while(cnt>0)
//     {
//         PRT_Printf("task 1 run ...\n");
//         cnt--;
//     }
// }
// void Test2TaskEntry()
// {
//     PRT_Printf("task 2 run ..\n");
//     ptr =NULL;

// }



S32 main(void)
{
  // 初始化GIC
    OsHwiInit();
    // 任务模块初始化
    OsTskInit();
    OsSemInit(); // 参见demos/ascend310b/config/prt_config.c 系统初始化注册表
// 启用Timer
    CoreTimerInit();
    PRT_UartInit();

    PRT_Printf("            _       _ _____      _             _             _   _ _   _ _   _           \n");
    PRT_Printf("  _ __ ___ (_)_ __ (_) ____|   _| | ___ _ __  | |__  _   _  | | | | \\ | | | | | ___ _ __ \n");
    PRT_Printf(" | '_ ` _ \\| | '_ \\| |  _|| | | | |/ _ \\ '__| | '_ \\| | | | | |_| |  \\| | | | |/ _ \\ '__|\n");
    PRT_Printf(" | | | | | | | | | | | |__| |_| | |  __/ |    | |_) | |_| | |  _  | |\\  | |_| |  __/ |   \n");
    PRT_Printf(" |_| |_| |_|_|_| |_|_|_____\\__,_|_|\\___|_|    |_.__/ \\__, | |_| |_|_| \\_|\\___/ \\___|_|   \n");
    PRT_Printf("                                                     |___/                               \n");

    PRT_Printf("ctr-a h: print help of qemu emulator. ctr-a x: quit emulator.\n\n");

    U32 ret;
    ret = PRT_SemCreate(0, &sem_sync);
    if (ret != OS_OK) {
        PRT_Printf("failed to create synchronization sem\n");
        return 1;
    }
    U32 ret1;
    ret = PRT_SemCreate(1, &sem1);
    if (ret != OS_OK) {
        PRT_Printf("failed to create synchronization sem\n");
        return 1;
    }U32 ret2;
    ret = PRT_SemCreate(1, &sem2);
    if (ret != OS_OK) {
        PRT_Printf("failed to create synchronization sem\n");
        return 1;
    }

    struct TskInitParam param = {0};

    // task 1
    // param.stackAddr = 0;
    param.taskEntry = (TskEntryFunc)Test1TaskEntry;
    param.taskPrio = 0;
    // param.name = "Test1Task";
    param.stackSize = 0x1000; //固定4096，参见prt_task_init.c的OsMemAllocAlign

    TskHandle tskHandle1;
    ret = PRT_TaskCreate(&tskHandle1, &param);
    if (ret) {
        return ret;
    }

    ret = PRT_TaskResume(tskHandle1);
    if (ret) {
        return ret;
    }

    // task 2
    // param.stackAddr = 0;
    param.taskEntry = (TskEntryFunc)Test2TaskEntry;
    param.taskPrio = 0;
    // param.name = "Test2Task";
    param.stackSize = 0x1000; //固定4096，参见prt_task_init.c的OsMemAllocAlign

    TskHandle tskHandle2;
    ret = PRT_TaskCreate(&tskHandle2, &param);
    if (ret) {
        return ret;
    }

    ret = PRT_TaskResume(tskHandle2);
    if (ret) {
        return ret;
    }

    // 启动调度
    OsActivate();

    // while(1);
    return 0;

}

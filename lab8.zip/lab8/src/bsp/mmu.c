#include "prt_typedef.h"
#include "prt_module.h"
#include "prt_errno.h"
#include "mmu.h"
#include "prt_task.h"
#include <stdarg.h>

extern U64 g_mmu_page_begin;
extern U64 g_mmu_page_end;

extern void os_asm_invalidate_dcache_all(void);
extern void os_asm_invalidate_icache_all(void);
extern void os_asm_invalidate_tlb_all(void);
// 测试高地址映射：向高地址写魔数，再从物理地址读回
static void mmu_test_high_addr_mapping(void);

// 打印寄存器状态
static void mmu_dump_registers(void);

extern int TryPrintf(const char *format, va_list vaList);
#define VIRT_UART_BASE  0xFFFFFFFF08000000UL
#define PHYS_UART_BASE  0x08010000UL

void Printf_MMU(const char *format, ...)
{
    va_list args;
    va_start(args, format);
    TryPrintf(format, args);  //正确使用 va_list 的 printf 实现
    va_end(args);
}

#define UART_0_REG_BASE (0xffffffff00000000 + 0x09000000)


#define GIC_DIST_BASE              (0xffffffff00000000 + 0x08000000)
#define GIC_CPU_BASE               (0xffffffff00000000 + 0x08010000)
static mmu_mmap_region_s g_mem_map_info[] = {
    {   // TTBR0 映射：低地址外设（假定 0～1G 的设备空间）
        .virt      = 0x00000000UL,
        .phys      = 0x00000000UL,
        .size      = 0x40000000UL,   // 1 GB
        .max_level = 2,
        .attrs     = MMU_ATTR_DEVICE_NGNRNE | MMU_ACCESS_RWX,
    },
    {   // TTBR0 映射：低地址普通内存（1G～2G）
        .virt      = 0x40000000UL,
        .phys      = 0x40000000UL,
        .size      = 0x40000000UL,   // 1 GB
        .max_level = 2,
        .attrs     = MMU_ATTR_CACHE_SHARE | MMU_ACCESS_RWX,
    },
    {   // 新增：TTBR0 映射：UART 物理地址的 identity 映射
        .virt      = UART_0_REG_BASE,    // UART 物理地址
        .phys      = 0x09000000UL,
        .size      = 0x1000UL,        // UART 占用大小，通常 4K 就够
        .max_level = 3,
        .attrs     = MMU_ATTR_DEVICE_NGNRNE | MMU_ACCESS_RWX,
    },
    {   // 新增：TTBR0 映射：UART 物理地址的 identity 映射
        .virt      = GIC_DIST_BASE,    // UART 物理地址
        .phys      = 0x08000000UL,
        .size      = 0x1000UL,        // UART 占用大小，通常 4K 就够
        .max_level = 3,
        .attrs     = MMU_ATTR_DEVICE_NGNRNE | MMU_ACCESS_RWX,
    },
    {   // 新增：TTBR0 映射：UART 物理地址的 identity 映射
        .virt      = GIC_CPU_BASE,    // UART 物理地址
        .phys      = 0x08010000UL,
        .size      = 0x1000UL,        // UART 占用大小，通常 4K 就够
        .max_level = 3,
        .attrs     = MMU_ATTR_DEVICE_NGNRNE | MMU_ACCESS_RWX,
    },
    {   // TTBR1 映射：高地址 UART 和 GIC_DIST
        .virt      = 0xFFFFFFFF08000000UL,
        .phys      = 0x08000000UL,
        .size      = 0x01000000UL,   // 16 MB，覆盖 GIC_DIST 和 UART
        .max_level = 2,
        .attrs     = MMU_ATTR_DEVICE_NGNRNE | MMU_ACCESS_RWX,
    },


};





static mmu_ctrl_s g_mmu_ctrl = { 0 };

// 依据实际情况生成tcr的值，pva_bits返回虚拟地址位数。Translation Control Register (tcr)
// static U64 mmu_get_tcr(U32 *pips, U32 *pva_bits)
// {
//     U64 max_addr = 0;
//     U64 ips, va_bits;
//     U64 tcr = 0;
//     U32 i;
//     U32 mmu_table_num = sizeof(g_mem_map_info) / sizeof(mmu_mmap_region_s);

//     // 修改这里：下半区用 36-bit，高地址（TTBR1）用 48-bit，确保能映射到 0xFFFFFFFF08000000
//     U32 low_va_bits  = 36;  // 64GB 虚拟地址空间用于 TTBR0
//     U32 high_va_bits = 48;  // 256TB 虚拟地址空间用于 TTBR1（含 0xFFFFFFFF00000000）

//     g_mmu_ctrl.t0sz = 64 - low_va_bits;
//     g_mmu_ctrl.t1sz = 64 - high_va_bits;

//     // 计算 max 物理地址
//     for (i = 0; i < mmu_table_num; ++i) {
//         max_addr = MAX(max_addr, g_mem_map_info[i].phys + g_mem_map_info[i].size);
//     }

//     // 设置 IPS（决定物理地址最大范围）
//     if (max_addr > (1ULL << MMU_BITS_44)) {
//         ips = MMU_PHY_ADDR_LEVEL_5;
//         va_bits = MMU_BITS_48;
//     } else if (max_addr > (1ULL << MMU_BITS_42)) {
//         ips = MMU_PHY_ADDR_LEVEL_4;
//         va_bits = MMU_BITS_44;
//     } else if (max_addr > (1ULL << MMU_BITS_40)) {
//         ips = MMU_PHY_ADDR_LEVEL_3;
//         va_bits = MMU_BITS_42;
//     } else if (max_addr > (1ULL << MMU_BITS_36)) {
//         ips = MMU_PHY_ADDR_LEVEL_2;
//         va_bits = MMU_BITS_40;
//     } else if (max_addr > (1ULL << MMU_BITS_32)) {
//         ips = MMU_PHY_ADDR_LEVEL_1;
//         va_bits = MMU_BITS_36;
//     } else {
//         ips = MMU_PHY_ADDR_LEVEL_0;
//         va_bits = MMU_BITS_32;
//     }

//     // 构造 TCR 值
//     tcr |= TCR_IPS(ips);

//     // TTBR0：低地址空间
//     tcr |= TCR_T0SZ(low_va_bits);
//     tcr |= TCR_TG0_4K;
//     tcr |= TCR_IRGN0_WBWA | TCR_ORGN0_WBWA | TCR_SHARED_INNER;

//     // TTBR1：高地址空间
//     tcr |= TCR_T1SZ(high_va_bits);  
//     tcr |= TCR_TG1_4K;
//     tcr |= TCR_IRGN1_WBWA | TCR_ORGN1_WBWA | TCR_SHARED_INNER;

//     if (pips != NULL) {
//         *pips = ips;
//     }
//     if (pva_bits != NULL) {
//         *pva_bits = va_bits;
//     }

//     return tcr;
// }
static U64 mmu_get_tcr(U32 *t0sz_out, U32 *t1sz_out, U32 *va_bits_out)
{
    U32 va_bits = 48; // 默认 VA 使用 48 位（可按需调整）

    U32 t0sz = 64 - va_bits;
    U32 t1sz = 64 - va_bits;

    // 记录输出参数
    if (t0sz_out) *t0sz_out = t0sz;
    if (t1sz_out) *t1sz_out = t1sz;
    if (va_bits_out) *va_bits_out = va_bits;

    U64 tcr = 0;

    tcr |= ((U64)t0sz << 0);      // T0SZ
    tcr |= ((U64)t1sz << 16);     // T1SZ
    tcr |= (0b00ULL << 14);       // TG0 = 4KB
    tcr |= (0b10ULL << 30);       // TG1 = 4KB
    tcr |= (0b11ULL << 12);       // SH0 = Inner Shareable
    tcr |= (0b11ULL << 28);       // SH1 = Inner Shareable
    tcr |= (0b01ULL << 8);        // ORGN0 = Write-back Write-allocate
    tcr |= (0b01ULL << 10);       // IRGN0 = Write-back Write-allocate
    tcr |= (0b01ULL << 24);       // ORGN1
    tcr |= (0b01ULL << 26);       // IRGN1
    tcr |= (0ULL << 7);           // EPD0 = Enable TTBR0
    tcr |= (0ULL << 23);          // EPD1 = Enable TTBR1

    return tcr;
}



static U32 mmu_get_pte_type(U64 const *pte)
{
    return (U32)(*pte & PTE_TYPE_MASK);
}

// 根据页表项级别计算当个页表项表示的范围（位数）
static inline U32 mmu_level2shift(U32 level)
{
    if (g_mmu_ctrl.granule == MMU_GRANULE_4K) {
        return 39 - level * 9; // L0=39, L1=30, L2=21, L3=12
    } else if (g_mmu_ctrl.granule == MMU_GRANULE_64K) {
        return 42 - level * 13; // L1=29, L2=16, L3=3
    } else {
        return 0; // 错误处理
    }
}


// 根据虚拟地址找到对应级别的页表项
static U64 *mmu_find_pte(U64 addr, U32 level)
{
    U64 *pte = NULL;
    U64 idx;
    U32 i;

    if (level < g_mmu_ctrl.start_level) {
        return NULL;
    }

    // 判断是使用 TTBR0 还是 TTBR1 页表
    // 用 g_mmu_ctrl.t0sz/t1sz 判断
    if (addr < (1ULL << (64 - g_mmu_ctrl.t0sz))) {
        pte = g_mmu_ctrl.ttbr0_base;//低地址
    } else {
        pte = g_mmu_ctrl.ttbr1_base;//高地址
    }


    // 从顶级页表遍历到目标 level
    for (i = g_mmu_ctrl.start_level; i < MMU_LEVEL_MAX; ++i) {
        // 计算当前级别页表索引
        if (g_mmu_ctrl.granule == MMU_GRANULE_4K) {
            idx = (addr >> mmu_level2shift(i)) & 0x1FF;
        } else {
            idx = (addr >> mmu_level2shift(i)) & 0x1FFF;
        }

        // 跳到对应的页表项
        pte += idx;

        if (i == level) {
            return pte; // 到达目标级别
        }

        // 检查该项是否指向下一级页表
        if (mmu_get_pte_type(pte) != PTE_TYPE_TABLE) {
            return NULL;
        }

        // 跟进到下一级页表地址
        if (g_mmu_ctrl.granule == MMU_GRANULE_4K) {
            pte = (U64 *)(*pte & PTE_TABLE_ADDR_MARK_4K);
        } else {
            pte = (U64 *)(*pte & PTE_TABLE_ADDR_MARK_64K);
        }
    }

    return NULL;
}


// 根据页表粒度在页表区域新建一个页表，返回页表起始位置
static U64 *mmu_create_table(void)
{
    U32 pt_len;
    U64 align_size;
    U64 aligned_addr;
    U64 *new_table;

    if (g_mmu_ctrl.granule == MMU_GRANULE_4K) {
        pt_len = MAX_PTE_ENTRIES_4K * sizeof(U64);  // 512 * 8 = 4096 = 4KB
        align_size = 0x1000; // 4KB
    } else {
        pt_len = MAX_PTE_ENTRIES_64K * sizeof(U64); // 512 * 8 = 4KB；64K 页表粒度页仍是 4KB 表
        align_size = 0x1000; // 仍按 4KB 对齐（ARMv8 页表每级都是 4KB）
    }

    // 强制对齐
    aligned_addr = (g_mmu_ctrl.tlb_fillptr + align_size - 1) & ~(align_size - 1);
    new_table = (U64 *)aligned_addr;

    // 更新填充指针
    g_mmu_ctrl.tlb_fillptr = aligned_addr + pt_len;

    // 检查是否超出页表区域
    if (g_mmu_ctrl.tlb_fillptr - g_mmu_ctrl.tlb_addr > g_mmu_ctrl.tlb_size) {
        return NULL;
    }

    // 初始化页表全为 0（PTE_TYPE_FAULT）
    for (U32 i = 0; i < pt_len / sizeof(U64); ++i) {
        new_table[i] = 0;
    }

    return new_table;
}


static void mmu_set_pte_table(U64 *pte, U64 *table)
{
    // https://developer.arm.com/documentation/den0024/a/The-Memory-Management-Unit/Translation-tables-in-ARMv8-A/AArch64-descriptor-format
    *pte = PTE_TYPE_TABLE | (U64)table;
}


// 依据mmu_mmap_region_s填充pte
static S32 mmu_add_map_pte_process(const mmu_mmap_region_s *map, U64 *pte, U64 phys, U32 level)
{
    U64 *new_table = NULL;

    // 还未到映射层级，需要创建下级页表
    if (level < map->max_level) {
        if (mmu_get_pte_type(pte) == PTE_TYPE_FAULT) {
            // 创建下级页表
            new_table = mmu_create_table();
            if (new_table == NULL) {
                return -1;
            }
            // 设置 PTE 指向新页表
            mmu_set_pte_table(pte, new_table);
        }
    } else {
        // 到达映射层级
        if (level == MMU_LEVEL_3) {
            // L3 页表项是 Page 类型
            *pte = phys | map->attrs | PTE_TYPE_PAGE;
        } else {
            // L0-L2 页表项是 Block 类型
            *pte = phys | map->attrs | PTE_TYPE_BLOCK;
        }
    }

    return 0;
}

static inline U64 mmu_va2index(U64 va, U32 level)
{
    if (g_mmu_ctrl.granule == MMU_GRANULE_4K) {
        // 每级页表索引 9bit（512项），偏移量由 level 决定
        return (va >> mmu_level2shift(level)) & 0x1FF;
    } else if (g_mmu_ctrl.granule == MMU_GRANULE_64K) {
        // 每级页表索引 13bit（8192项）
        return (va >> mmu_level2shift(level)) & 0x1FFF;
    } else {
        // 不支持的页粒度
        return 0;
    }
}




static S32 mmu_set_block_entry(U64 *pte, U64 phys, U64 attr, U32 level)
{
    U64 desc;

    // L3 必须使用 PAGE 类型，否则使用 BLOCK
    if (level == 3) {
        desc = PTE_TYPE_PAGE;
    } else {
        desc = PTE_TYPE_BLOCK;
    }

    // 清理地址保留位（保证对齐）
    if (g_mmu_ctrl.granule == MMU_GRANULE_4K) {
        phys &= ~0xFFFULL;
    } else {
        phys &= ~0xFFFFULL;
    }

    desc |= phys;   // 设置物理地址
    desc |= attr;   // 设置属性

    *pte = desc;
    return 0;
}

static U64 *mmu_find_or_alloc_pte_with_base(U64 *base_table, U64 va, U32 target_level)
{
    U64 *table = base_table;
    U32 level = g_mmu_ctrl.start_level;
    U32 index;
    U64 desc;

    while (level < target_level) {
        index = mmu_va2index(va, level);
        desc = table[index];

        if ((desc & 0x3) == PTE_TYPE_TABLE) {
            // 已存在下一级页表
            table = (U64 *)(desc & PTE_ADDR_MASK);
        } else if ((desc & 0x3) == PTE_TYPE_INVALID) {
            // 分配下一级页表
            U64 *next_table = mmu_create_table();
            if (!next_table) {
                return NULL;
            }

            // 设置该表项指向新页表（有效 + table type）
            table[index] = ((U64)next_table & PTE_ADDR_MASK) | PTE_TYPE_TABLE;

            table = next_table;
        } else {
            // 非法情况（例如该位置已有 block）
            return NULL;
        }

        level++;
    }

    // 返回目标层级的 PTE 指针
    index = mmu_va2index(va, target_level);
    return &table[index];
}


static S32 mmu_add_map(const mmu_mmap_region_s *map, U64 *base_table)
{
    U64 virt = map->virt;
    U64 phys = map->phys;
    U64 size = map->size;
    U32 level;
    S32 ret;

    if (!map || size == 0 || !base_table) {
        return -1;
    }

    while (size > 0) {
        S32 mapped = 0;

        // 从高到低层级尝试映射
        for (level = g_mmu_ctrl.start_level; level <= map->max_level; ++level) {
            U64 level_shift = mmu_level2shift(level);
            U64 block_size = 1ULL << level_shift;
            U64 block_mask = block_size - 1;

            // 如果 VA 或 PA 对齐不满足，或当前 size 不够大，跳过该级别
            if ((virt & block_mask) || (phys & block_mask) || (size < block_size)) {
                continue;
            }

            // 找到或分配页表项，传入 base_table
            U64 *pte = mmu_find_or_alloc_pte_with_base(base_table, virt, level);
            if (!pte) {
                Printf_MMU("[MMU] Failed to allocate PTE for VA: 0x%016llx, level %u\n", virt, level);
                return -2;
            }

            // 设置该 block 映射
            ret = mmu_set_block_entry(pte, phys, map->attrs, level);
            if (ret) {
                Printf_MMU("[MMU] Failed to set block entry at level %u\n", level);
                return -3;
            }

            // 成功映射一个 block
            virt += block_size;
            phys += block_size;
            size -= block_size;
            mapped = 1;
            break;  // 进入下一个块映射
        }

        if (!mapped) {
            Printf_MMU("[MMU] Cannot map VA: 0x%016llx, size: 0x%llx\n", virt, size);
            return -4;
        }
    }

    return 0;
}




static inline void mmu_set_ttbr_tcr_mair(U64 ttbr0, U64 ttbr1, U64 tcr, U64 attr)
{
    OS_EMBED_ASM("dsb sy");

    OS_EMBED_ASM("msr ttbr0_el1, %0" : : "r" (ttbr0) : "memory");
    OS_EMBED_ASM("msr ttbr1_el1, %0" : : "r" (ttbr1) : "memory");
    OS_EMBED_ASM("msr tcr_el1, %0"   : : "r" (tcr)   : "memory");
    OS_EMBED_ASM("msr mair_el1, %0"  : : "r" (attr)  : "memory");

    OS_EMBED_ASM("isb");
    //Printf_MMU("[MMU] TTBR0 base: 0x%llx\n", (uint64_t)(uintptr_t)g_mmu_ctrl.ttbr0_base);
   // Printf_MMU("[MMU] TTBR1 base: 0x%llx\n", (uint64_t)(uintptr_t)g_mmu_ctrl.ttbr1_base);


}

// 设置页表结构并配置 TCR、MAIR、TTBR 等寄存器
// static U32 mmu_setup_pgtables(mmu_mmap_region_s *mem_map, U32 mem_region_num,
//                               U64 tlb_addr, U64 tlb_len, U32 granule)
// {
//     U32 i;
//     U32 ret;
//     U64 tcr;

//     // 初始化 mmu 控制器全局变量
//     g_mmu_ctrl.tlb_addr     = tlb_addr;
//     g_mmu_ctrl.tlb_size     = tlb_len;
//     g_mmu_ctrl.tlb_fillptr  = tlb_addr;
//     g_mmu_ctrl.granule      = granule;

//     // 计算虚拟地址位数，生成 TCR 值
//     tcr = mmu_get_tcr(NULL, &g_mmu_ctrl.va_bits);

//     // 依据 granule 和 VA 位数，确定页表起始层级
//     if (granule == MMU_GRANULE_4K) {
//         g_mmu_ctrl.start_level = (g_mmu_ctrl.va_bits < MMU_BITS_39) ? MMU_LEVEL_1 : MMU_LEVEL_0;
//     } else {
//         if (g_mmu_ctrl.va_bits <= MMU_BITS_36) {
//             g_mmu_ctrl.start_level = MMU_LEVEL_2;
//         } else {
//             return 3; // 不支持大于36位VA的64K页
//         }
//     }

//     // 为 TTBR0_EL1 和 TTBR1_EL1 分配顶层页表
//     g_mmu_ctrl.ttbr0_base = mmu_create_table();
//     g_mmu_ctrl.ttbr1_base = mmu_create_table();
//     if (!g_mmu_ctrl.ttbr0_base || !g_mmu_ctrl.ttbr1_base) {
//         return 1; // 内存分配失败
//     }

//     // 遍历映射表并将其添加到对应页表结构中
//     for (i = 0; i < mem_region_num; ++i) {
//         mmu_mmap_region_s *map = &mem_map[i];
//         U64 *base_table;

//         // 判断当前映射区域属于 TTBR0（低地址）还是 TTBR1（高地址）
//         if (map->virt < (1ULL << (64 - g_mmu_ctrl.t0sz))) {
//             base_table = g_mmu_ctrl.ttbr0_base;
//         } else {
//             base_table = g_mmu_ctrl.ttbr1_base;
//         }

//         // 添加映射，传入 base_table 而不是修改 tlb_addr
//         ret = mmu_add_map(map, base_table);
//         if (ret) {
//             return ret;
//         }
//     }

//     // 设置 TTBR0_EL1 和 TTBR1_EL1、TCR_EL1、MAIR_EL1
//     mmu_set_ttbr_tcr_mair((U64)g_mmu_ctrl.ttbr0_base,
//                           (U64)g_mmu_ctrl.ttbr1_base,
//                           tcr,
//                           MEMORY_ATTRIBUTES);

//     // 打印信息，验证映射到高地址
//     uint64_t v = (uint64_t)g_mmu_ctrl.ttbr1_base;
//     Printf_MMU("[MMU] TTBR1 base (low32): 0x%08x\n", (uint32_t)(v & 0xFFFFFFFF));

//     return 0;
// }

static U32 mmu_setup_pgtables(mmu_mmap_region_s *mem_map, U32 mem_region_num,
                              U64 tlb_addr, U64 tlb_len, U32 granule)
{
    U32 i;
    U32 ret;
    U64 tcr;
    U32 t0sz, t1sz, va_bits;

    // 初始化 mmu 控制器全局变量
    g_mmu_ctrl.tlb_addr     = tlb_addr;
    g_mmu_ctrl.tlb_size     = tlb_len;
    g_mmu_ctrl.tlb_fillptr  = tlb_addr;
    g_mmu_ctrl.granule      = granule;

    // 获取 TCR 配置，同时得到 VA 位数、T0SZ、T1SZ
    tcr = mmu_get_tcr(&t0sz, &t1sz, &va_bits);
    g_mmu_ctrl.va_bits = va_bits;
    g_mmu_ctrl.t0sz = t0sz;
    g_mmu_ctrl.t1sz = t1sz;

    // 根据 VA 位数和粒度，确定起始页表层级
    if (granule == MMU_GRANULE_4K) {
        g_mmu_ctrl.start_level = (va_bits < 39) ? MMU_LEVEL_1 : MMU_LEVEL_0;
    } else {
        if (va_bits <= 36) {
            g_mmu_ctrl.start_level = MMU_LEVEL_2;
        } else {
            return 3; // 不支持 >36 位的 VA（64KB 粒度）
        }
    }

    // 分配顶级页表
    g_mmu_ctrl.ttbr0_base = mmu_create_table();
    g_mmu_ctrl.ttbr1_base = mmu_create_table();
    if (!g_mmu_ctrl.ttbr0_base || !g_mmu_ctrl.ttbr1_base) {
        return 1; // 分配失败
    }

    // 遍历所有内存区域并建立映射
    for (i = 0; i < mem_region_num; ++i) {
        mmu_mmap_region_s *map = &mem_map[i];
        U64 *base_table;

        // 根据虚拟地址选择 TTBR0 或 TTBR1
        if (map->virt < (1ULL << (64 - g_mmu_ctrl.t0sz))) {
            base_table = g_mmu_ctrl.ttbr0_base;
        } else {
            base_table = g_mmu_ctrl.ttbr1_base;
        }

        ret = mmu_add_map(map, base_table);
        if (ret) {
            return ret;
        }
    }

    // 设置 MAIR_EL1、TCR_EL1、TTBRx_EL1
    mmu_set_ttbr_tcr_mair((U64)g_mmu_ctrl.ttbr0_base,
                          (U64)g_mmu_ctrl.ttbr1_base,
                          tcr,
                          MEMORY_ATTRIBUTES);

    // 调试打印
    Printf_MMU("[MMU] TTBR0 base: 0x%016llx\n", (U64)g_mmu_ctrl.ttbr0_base);
    Printf_MMU("[MMU] TTBR1 base: 0x%016llx\n", (U64)g_mmu_ctrl.ttbr1_base);

    return 0;
}


static S32 mmu_setup(void)
{
    S32 ret;//用于保存函数调用返回值
    U64 page_addr;//页表的起始物理地址
    U64 page_len;//页表总长度

    page_addr = (U64)&g_mmu_page_begin;
    page_len = (U64)&g_mmu_page_end - (U64)&g_mmu_page_begin;

    ret = mmu_setup_pgtables(g_mem_map_info, (sizeof(g_mem_map_info) / sizeof(mmu_mmap_region_s)),
                            page_addr, page_len, MMU_GRANULE_4K);//构建完整页表
    if (ret) {
        return ret;
    }

    return 0;
}



S32 mmu_init(void)
{
    S32 ret;

    PRT_UartInit();  // 初始化串口
    Printf_MMU("UART OK\n");

    Printf_MMU("[MMU_INIT] Step 1: Calling mmu_setup()\n");
    ret = mmu_setup();
    if (ret) {
        Printf_MMU("[MMU_INIT] mmu_setup() failed! ret = %d\n", ret);
        return ret;
    }
    Printf_MMU("[MMU_INIT] Step 2: mmu_setup() success\n");

    os_asm_invalidate_dcache_all();
    os_asm_invalidate_icache_all();
    os_asm_invalidate_tlb_all();
    Printf_MMU("[MMU_INIT] Step 3: Invalidated DCache, ICache, TLB\n");

    // 启用 MMU、Cache、Instruction Cache
    U32 sctlr = get_sctlr();
    Printf_MMU("[MMU_INIT] Step 4: Before set_sctlr, SCTLR=0x%x\n", sctlr);
    sctlr |= (CR_C | CR_M | CR_I);
    set_sctlr(sctlr);
    OS_EMBED_ASM("isb");  // 保证设置立即生效
    Printf_MMU("[MMU_INIT] Step 5: After set_sctlr, SCTLR=0x%x\n", get_sctlr());

    Printf_MMU("[MMU_INIT] Step 6: Dump MMU Registers\n");
    mmu_dump_registers();

    Printf_MMU("[MMU_INIT] Step 7: Testing high address mapping\n");
    mmu_test_high_addr_mapping();
    Printf_MMU("[MMU_INIT] Step 8: mmu_test_high_addr_mapping() completed\n");

    return 0;
}


// 打印 TTBR0_EL1、TTBR1_EL1、TCR_EL1
static void mmu_dump_registers(void)
{
    uint64_t val;
    // TTBR0_EL1
    asm volatile("mrs %0, ttbr0_el1" : "=r"(val));
    Printf_MMU("[MMU DUMP] TTBR0_EL1 = 0x%08x%08x\n",
               (uint32_t)(val >> 32), (uint32_t)val);
    // TTBR1_EL1
    asm volatile("mrs %0, ttbr1_el1" : "=r"(val));
    Printf_MMU("[MMU DUMP] TTBR1_EL1 = 0x%08x%08x\n",
               (uint32_t)(val >> 32), (uint32_t)val);
    // TCR_EL1
    asm volatile("mrs %0, tcr_el1"   : "=r"(val));
    Printf_MMU("[MMU DUMP] TCR_EL1   = 0x%08x%08x\n",
               (uint32_t)(val >> 32), (uint32_t)val);
}

static void mmu_test_high_addr_mapping(void)
{
    volatile uint8_t *uart = (uint8_t *)VIRT_UART_BASE;

    Printf_MMU("[MMU TEST] Writing 'M' to high addr 0x%llx\n", (uint64_t)uart);
    *uart = 'M'; // 写入一个字符测试串口

    Printf_MMU("[MMU TEST] UART write complete\n");
}


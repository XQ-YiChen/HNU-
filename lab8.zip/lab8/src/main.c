#include "prt_typedef.h"
#include "prt_tick.h"
#include "prt_task.h"
#include "prt_sem.h"

extern U32 PRT_Printf(const char *format, ...);
extern void PRT_UartInit(void);
extern U32 OsActivate(void);
extern U32 OsTskInit(void);
extern U32 OsSemInit(void);
extern U32 OsHwiInit(void);
extern void CoreTimerInit(void);
static SemHandle sem_sync;

void Delay(U64 delay_ms)
{
    U64 end_time = PRT_TickGetCount() + delay_ms;
    while (PRT_TickGetCount() < end_time)
        ;
}

static SemHandle sem1;
static SemHandle sem2;

void Test1TaskEntry()
{
    PRT_Printf("task 1 run ...\n");
    PRT_SemPost(sem_sync);  // 释放任务 2 的信号量
    U32 cnt = 5;
    while (cnt > 0) {
        PRT_Printf("task 1 run ...\n");
        Delay(100);  // 添加延时，避免输出过快
        cnt--;
    }
}

void Test2TaskEntry()
{
    PRT_Printf("task 2 run ...\n");
    PRT_SemPend(sem_sync, OS_WAIT_FOREVER);  // 等待任务 1 完成后启动
    U32 cnt = 5;
    while (cnt > 0) {
        PRT_Printf("task 2 run ...\n");
        Delay(100);  // 添加延时，避免输出过快
        cnt--;
    }
}

S32 main(void)
{
    // 初始化GIC
    OsHwiInit();
    // 任务模块初始化
    OsTskInit();
    OsSemInit(); // 参见demos/ascend310b/config/prt_config.c 系统初始化注册表
    // 启用Timer
    CoreTimerInit();
    PRT_UartInit();

    PRT_Printf("            _       _ _____      _             _             _   _ _   _ _   _           \n");
    PRT_Printf("  _ __ ___ (_)_ __ (_) ____|   _| | ___ _ __  | |__  _   _  | | | | \\ | | | | | ___ _ __ \n");
    PRT_Printf(" | '_ ` _ \\| | '_ \\| |  _|| | | | |/ _ \\ '__| | '_ \\| | | | | |_| |  \\| | | | |/ _ \\ '__|\n");
    PRT_Printf(" | | | | | | | | | | | |__| |_| | |  __/ |    | |_) | |_| | |  _  | |\\  | |_| |  __/ |   \n");
    PRT_Printf(" |_| |_| |_|_|_| |_|_|_____\\__,_|_|\\___|_|    |_.__/ \\__, | |_| |_|_| \\_|\\___/ \\___|_|   \n");
    PRT_Printf("                                                     |___/                               \n");

    PRT_Printf("ctr-a h: print help of qemu emulator. ctr-a x: quit emulator.\n\n");

    U32 ret;
    ret = PRT_SemCreate(0, &sem_sync);
    if (ret != OS_OK) {
        PRT_Printf("failed to create synchronization sem\n");
        return 1;
    }
    
    ret = PRT_SemCreate(1, &sem1);
    if (ret != OS_OK) {
        PRT_Printf("failed to create synchronization sem\n");
        return 1;
    }

    ret = PRT_SemCreate(1, &sem2);
    if (ret != OS_OK) {
        PRT_Printf("failed to create synchronization sem\n");
        return 1;
    }

    struct TskInitParam param = {0};

    // task 1
    param.taskEntry = (TskEntryFunc)Test1TaskEntry;
    param.taskPrio = 0;
    param.stackSize = 0x1000;

    TskHandle tskHandle1;
    ret = PRT_TaskCreate(&tskHandle1, &param);
    if (ret) {
        return ret;
    }

    ret = PRT_TaskResume(tskHandle1);
    if (ret) {
        return ret;
    }

    // task 2
    param.taskEntry = (TskEntryFunc)Test2TaskEntry;
    param.taskPrio = 0;
    param.stackSize = 0x1000;

    TskHandle tskHandle2;
    ret = PRT_TaskCreate(&tskHandle2, &param);
    if (ret) {
        return ret;
    }

    ret = PRT_TaskResume(tskHandle2);
    if (ret) {
        return ret;
    }

    // 启动调度
    OsActivate();

    return 0;
}
